/*מוחמד כנעאן - 205722176 */
/*שימאא עואד - 212083653 */
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

/* This function reads the input file and calls the appropriate handler functions for each line.*/
void firstStage(char *fileName);

/* This function handles a line of data type commands (e.g., .data, .string, or .struct) and updates the data command accordingly*/
void dataHandler(int hasLabel, char *seporators, char *labelName);

/* This function handles a line of .string type command and updates the data command accordingly*/
void stringHandler(char *seporators, char *labelName, int lineNumber);

/* This function handles a line of .struct type command and updates the data command accordingly*/
void structHandler(char *seporators, char *labelName, int lineNumber);

/* This function handles a line of .extern type command and updates the symbol table accordingly*/
void externHandler(char *seporators, char *labelName, int lineNumber);

/* This function handles a line of .entry type command and updates the symbol table accordingly*/
void entryHandler(char *seporators, char *labelName, int lineNumber);

/* This function handles a line of command type (e.g., mov, cmp, etc.) and updates the command accordingly.*/
void commandHandler(int hasLabel, char * lineSegment, char *seporators, char *labelName, int lineNumber);

/* This function updates the addresses of commands in the command after the first pass, by adding the offset value to each command's address*/
void updateCommandAddress(command **head, int offset, int labelCommand);
