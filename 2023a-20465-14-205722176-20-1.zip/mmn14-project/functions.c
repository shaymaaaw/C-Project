/*מוחמד כנעאן - 205722176 */
/*שימאא עואד - 212083653 */
#include "main.h"

command *macroCommand;
int hasErrors;

// Checks whether a given string is a valid label in the assembly code.
int checkLabelValidity(char *val, int withColon)
{
	// get the length of the string
	int length = strlen(val);
	int i;

    // check if the first character is a letter
	if ((isalpha(val[0]))) 
	{
		if(withColon) // if withColon is true, decrease the length by one to ignore the colon
			length = length -1;
		for(i =0; i < length; i++) // check that all the characters are letters or digits
			if (!isalpha(val[i]) && !isdigit(val[i]))
				return 0;
		// if withColon is true, check that the last character is a colon
		if ((withColon && val[length] == ':') || !withColon)
			return 1;
	}	
	return 0;
}

// This function checks whether a given label already exists in a list of command nodes,
// which is represented by the head pointer "headLabelCommand".
int checkLabelValidityExists(char *label,  command *headLabelCommand, int external)
{
	command* pntCommand;
	for (pntCommand = (headLabelCommand); pntCommand; pntCommand = pntCommand->next) // Check if the label name of the current command matches the given label name
		if (!strcmp(pntCommand->name, label)) // Check if external flag is set and the current command is external
		    if(!external || (external && strcmp(pntCommand->type, "exteral")))
			    return 1;  
	return 0;
}

// Checks if the given string is a valid register name.
int checkRegisterValidity(char *val)
{
	// Allocate memory for a new string that excludes the 'r' prefix
  	char * number = malloc(strlen(val)-1);
	strcpy(number, val+1);
	int regNumber = atoi(number); //Convert the new string to an integer
	// Check if the new string starts with 'r' and the integer value is between 0 and 7 (inclusive)
	if(val[0] == 'r' && regNumber >= 0 && regNumber<= 7)
		return 1;	
	return 0;
}

// Check if a given string is an immediate value.
int checkImmidiateValidity(char *val)
{
	// Allocate memory for a string that contains the numeric value of the immediate.
    char * number = malloc(strlen(val)-1);
	strcpy(number, val+1);
	if(checkNumberValidity(number)==0) // Check if the number string is a valid number.
	    return 0;
	if(val[0] == '#') // Check if the immediate starts with a hash symbol.
		return 1;
	return 0;
}

// Checks if the given string represents a valid number.
int checkNumberValidity(char *val)
{
    int length = strlen(val), i;
	// The first character can be a minus sign or a digit
    if(val[0] != '-' && isdigit(val[0]) == 0)
        return 0;
    for(i =1; i < length; i++)
        if(isdigit(val[i]) == 0)
            return 0;
    return 1;
}

// This function takes a string "val" representing an operand and returns an integer representing the addressing method
int getMethodNumber(char *val)
{
    if (checkRegisterValidity(val)) // If val is a register, return 3
        return 3;
    
    else if (checkImmidiateValidity(val)) // If val is an immediate, return 0
        return 0;
    
    else if(checkJumpValidity(val)) // If val is a jump parameter, return 2
        return 2;
   
    else if (checkLabelValidity(val, 0))  // If val is a label, return 1
        return 1;
    
    else return -1;
}

// This function takes a string input as an argument and returns the first parameter of a jump instruction.
// It is assumed that the input string is in the format "jmp parameter(label)" or "jmp parameter(register)".
char * extractJumpFirstParam(char *val)
{
	char *lineSegment;
	char *valCopy = malloc(sizeof(val));;

	strcpy(valCopy ,val);
	lineSegment = strtok(valCopy, " \t\n"); // get the first token (substring) of valCopy string and assign it to lineSegment pointer
	lineSegment = strtok(NULL, "(,"); // get the second token of valCopy string and assign it to lineSegment pointer
	return lineSegment;
}

// The extractJumpLabel function takes a string tok as input, which is expected to contain a label and possibly other characters after it. 
// It copies the tok string to another string tokCopy to preserve the original input.
char * extractJumpLabel(char *tok)
{
	char *lineSegment, *tokCopy = malloc(sizeof(tok));
	strcpy(tokCopy ,tok);
	lineSegment = strtok(tokCopy, " \t\n"); // get the first token of the input string, which is the label/jump name
	return lineSegment;
}

// This function checks whether the given input string represents a valid jump command parameter or not.
int checkJumpValidity(char *val)
{
	char *lineSegment, *strtolEnd, *valCopy = malloc(sizeof(val));
	int strtolInt;
	
	strcpy(valCopy ,val);
	lineSegment = strtok(valCopy, "."); // splitting the input string by the '.' delimiter.
	
	if (checkLabelValidity(lineSegment, 0)) // checking if the first segment is a valid label.
	{
	    lineSegment = strtok(NULL, " \t\n");
		if (lineSegment != NULL)
		{
		    strtolInt = strtol(lineSegment, &strtolEnd, 10); // converting the next segment to an integer.
            if(strtolInt == 1 || strtolInt == 2)
                return 1;
            else return 0;
		}
		else return 0;
	}
	else return 0;
}

// The function adds a new node to the end of a command linked list. The linked list is created using the command struct defined earlier. 
void addToCommand(command **head, char *label, int number, char *val, int address)
{
	command* tempCommand = (command*)malloc(sizeof(command)), *pntCommand1, *pntCommand2;
	
	if (!tempCommand)
	{
		printf("Erroe: Allocate memory error!");
		exit(0);
	}
	if (val != NULL)
		strcpy(tempCommand->type, val);
	if (label != NULL)
		strcpy(tempCommand->name, label);
	tempCommand->num = number;
    
	// find the end of the command linked list
	for (pntCommand1 = (*head); pntCommand1; pntCommand1 = pntCommand1->next)
		pntCommand2 = pntCommand1;

	if (pntCommand1 == (*head)) // add the new node to the end of the linked list
	{
		(*head) = tempCommand;
		tempCommand->next = NULL;
	}
	else
	{  
		pntCommand2->next = tempCommand;
		tempCommand->next = NULL;
	}
	if(val != NULL && (!strcmp(val, "e"))) // set the node's address based on the value and type
		tempCommand->address = 0;
	else
		tempCommand->address = address ;	
}

//The function definition that takes a pointer to a pointer to a command structure as input and does not return anything.
void clearCommand(command **headCode)
{
	command* pntCommand;
	// Traverse the linked list and free the memory allocated to each node
	while(*headCode)
	{
		pntCommand = (*headCode);
		(*headCode) = pntCommand->next;
		free(pntCommand);
	}
}

// This function removes macros from an assembly code file by reading each line of the file and writing it to a new file
// (with the same name as the original file with a suffix "_am" added to the end)
void removeMacros(char *file, char *amFile)
{
    FILE *amInputFile, *inputFile;
    char *separators = "\t\n, \r", *currentlineSegment, *nameOfMacro, *nameOfMacroCopy, line[100], copyLineSeg[100];
	int macroSpread = 0;
	
    amInputFile = fopen(amFile, "wb");
    inputFile = fopen(file, "r");
    if (inputFile == NULL)
	{
		printf("could not open file %s\n", file);
		int hasErrors = 1;
		
	}
	else if (amInputFile == NULL)
	{
		printf("could not open file %s\n", amFile); // check if amInputFile is NULL, i.e., the file could not be opened
		int hasErrors = 1; // set the variable hasErrors to 1 (presumably to indicate that an error occurred)
	}
	else
	{
	while (fgets(line, 80, inputFile) != NULL)
	{
		if (line[0] == '\n') continue; // skip empty lines
		if (feof(inputFile) == 0)
			*(strchr(line, '\n')) = '\0'; // remove trailing newline character
		strcpy(copyLineSeg, line); // make a copy of the line
		currentlineSegment = strtok(copyLineSeg, separators); // get the first token
		if (strcmp(currentlineSegment, "mcr")==0) // if the token is "mcr"
		{
			nameOfMacro = strtok(NULL, separators); // get the next token
			nameOfMacroCopy = malloc(sizeof(nameOfMacro)); // allocate memory for the name of the macro
			strcpy(nameOfMacroCopy, nameOfMacro);
			while (fgets(line, 80, inputFile) != NULL) // read lines from file until "endmcr" is found
			{
				strcpy(copyLineSeg, line);
				currentlineSegment = strtok(copyLineSeg, separators); // get the first token
				if (strcmp(currentlineSegment, "endmcr")==0) break; // break the loop if the token is "endmcr"
				else
					addToCommand(&macroCommand, nameOfMacroCopy, 0, line , 0); // add the line to the macro command list		        
			}
		}
		else // if the token is not "mcr"
		{
			command* pntCommand1;
			for (pntCommand1 = (macroCommand); pntCommand1; pntCommand1 = pntCommand1->next)
				if (strcmp(pntCommand1->name, currentlineSegment) == 0) // if the token matches the name of a macro
				{
					fprintf(amInputFile, "%s\n", pntCommand1->type); // write the type of the macro to the am file
					macroSpread = 1;
				}
			if(macroSpread == 0)
				fprintf(amInputFile, "%s\n", line); // write the line to the am file
			macroSpread = 0;
		}
	}
	fclose(inputFile);
	fclose(amInputFile);
	}
}
