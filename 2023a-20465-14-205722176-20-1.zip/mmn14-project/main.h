/*מוחמד כנעאן - 205722176 */
/*שימאא עואד - 212083653 */
#include "dataTypes.h"
#include "find.h"
#include "first.h"
#include "second.h"
#include "functions.h"
