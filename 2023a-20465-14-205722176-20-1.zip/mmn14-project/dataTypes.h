/*מוחמד כנעאן - 205722176 */
/*שימאא עואד - 212083653 */
#ifndef MY_DATA_TYPES_H
#define MY_DATA_TYPES_H

/* Define a new data type called "command" */
typedef struct command{
	char name[255]; /* A string to hold the name of the command	*/
	unsigned int address; /* A number to hold the memory address of the command */
	char type[255]; /* A string to hold the type of the command */
    int num;
    struct command *next; /* A pointer to another "command" struct, used to create a linked of commands */
}command;

#endif
