/*מוחמד כנעאן - 205722176 */
/*שימאא עואד - 212083653 */
#include "main.h"

int DC = 0, IC = 100;
int ICS, DCS; /*Store the final value of the data counter and instruction counter */
int hasLabel, hasErrors = 0;
command *codeCommand, *dataCommand, *labelCommand, *entCommand;

/*First passage File*/
void firstStage(char *fileName)
{
    FILE *file;
	char *seperators= "\t\n, ()\r", *lineSegment, *labelName, line[100];
	int lineNumber = 0;

	file = fopen(fileName, "r");
	
	/* read line by line from file */
	while (fgets(line, 80, file) != NULL) 
	{
	    hasLabel = 0;
		lineNumber++;
		
		/* read the first lineSegment from the line */
		lineSegment = strtok(line, seperators);
		 /* check if the line is not a comment */
		if (lineSegment != NULL && lineSegment[0] != ';')
		{
		    /* Check if the current lineSegment is a label (indicated by a colon at the end of the lineSegment)*/
			if (checkLabelValidity(lineSegment, 1))
			{
			     /* Check if the label already exists in the symbol table */
				if (checkLabelValidityExists(lineSegment, labelCommand, 0))
				{
					/* If the label already exists, print an error message and set a flag to indicate that the file has errors*/
					printf("Error Line:%d  label already exists\n" , lineNumber);
					hasErrors = 1;
					continue;
				}
				else
				{
					/* If the label doesn't already exist, set a flag to indicate that there is a label on this line, and store the label name */
					hasLabel = 1;
					labelName = lineSegment;
		            lineSegment = strtok(NULL, seperators);
				}
			}
			
			/* Check if the current lineSegment is ".data"*/
			if (!strcmp(lineSegment, ".data")) /* If the lineSegment is ".data", call a function to handle the data line */
                dataHandler(hasLabel, seperators, labelName);

			/* Check if the line continues with a string	*/
			else if (!strcmp(lineSegment, ".string"))
			    stringHandler(seperators, labelName, lineNumber);

			/* Check if the line begins with "extern*/
			else if (!strcmp(lineSegment, ".extern"))
                externHandler(seperators, labelName, lineNumber);

			/* Check if the line begins with "entry"*/
			else if (!strcmp(lineSegment, ".entry"))
			    entryHandler(seperators, labelName, lineNumber);

			/* Otherwise, the line must continue with a command*/
			else 
                commandHandler(hasLabel, lineSegment, seperators, labelName, lineNumber);
		}
	}
	fclose(file);
	
	ICS = IC; /* Store the final value of the instruction counter in ICS.*/
	DCS = DC;  /* Store the final value of the data counter in DCS.*/

	/* Update the address of the data in the dataCommand by adding the Instruction Count Final (ICS) value to the current address. */
	updateCommandAddress(&dataCommand, ICS, 0);

	/* Update the address of the labels in the labelCommand by adding the Instruction Count Final (ICS) value to the current address, and indicating that these are labels (passing 1 as the second argument).*/
	updateCommandAddress(&labelCommand, ICS, 1);
}

/* This function handles lines that start with .data and adds the data values to the data command */
void dataHandler(int hasLabel, char *seperators, char *labelName)
{
	/* lineSegmentize the input line to extract the first data value*/
    char *strtolEnd;
    char * lineSegment = strtok(NULL, seperators);
	int strtolInt = strtol(lineSegment, &strtolEnd, 10);

	/* Add the first data value to the data command */
	if(hasLabel == 1)
	{
		addToCommand(&dataCommand , labelName, strtolInt, "d", DC);
		addToCommand(&labelCommand, labelName, 0, "data", DC); 
	}
	else /* if the current data command doesn't have a label, add it to the data command with a NULL label*/
		addToCommand(&dataCommand , NULL, strtolInt, "d", DC);
	++DC;
 	/* Continue lineSegmentizing the line and adding the data values to the data command */
	lineSegment = strtok(NULL, seperators);
						
	/* iterate through all remaining lineSegments in the line*/
	while (lineSegment != NULL)
	{
		strtolInt = strtol(lineSegment, &strtolEnd, 10); /* convert the lineSegment to an integer*/
		addToCommand(&dataCommand, NULL, strtolInt, "d", DC); /* add the integer to the data command*/ 
		lineSegment = strtok(NULL, seperators); /* get the next lineSegment*/
		++DC;
	}
}

/* This function handles a line that contains a string, delimited by quotes.*/
/* The function takes a string of separators, the label name (if any), and the line number.*/
void stringHandler(char *seperators, char *labelName, int lineNumber)
{
    char *lineSegment = strtok(NULL, seperators); /* Get the next lineSegment in the input line*/
	int lineSegmentLen = strlen(lineSegment); /* Determine the length of the lineSegment*/
	int i;
	/* Check if the lineSegment starts and ends with quotes*/
	if ((lineSegment[0] == '"') && (lineSegment[lineSegmentLen-1] == '"'))
	{
		/*add first char and label*/
		int curChar = lineSegment[1];
		/* Add the first character to the data command*/
		if(hasLabel == 1)
		{
			addToCommand(&dataCommand , labelName, (int)curChar, "d", DC);
			addToCommand(&labelCommand, labelName, 0, "data", DC); 
		}
		else
			addToCommand(&dataCommand , NULL, (int)curChar, "d", DC);
		++DC;
		/*/ Add the rest of the characters to the data command*/
		for (i = 2; i < lineSegmentLen-1; ++i)
		{
			curChar = lineSegment[i];
			addToCommand(&dataCommand, "", (int)curChar, "d", DC);
			++DC; 
		}
		/* Add a null character to the end of the string*/
		addToCommand(&dataCommand, "", 0, "d", DC);
		++DC; 
	}
	else
	{
		/* Display an error message if the lineSegment is not enclosed in quotes*/
		printf("Error Line:%d  missing quates\n" , lineNumber);
		hasErrors = 1;
	}    
}

/* This function handles a line that starts with the ".extern" directive.*/
/* It takes a string of characters that separate words, a label name (if there is one), and the current line number.*/
void externHandler(char *seperators, char *labelName, int lineNumber)
{
	/* Get the next lineSegment in the input string.*/
    char *	lineSegment = strtok(NULL, seperators);
	if (checkLabelValidity(lineSegment, 0)) /* Check if the lineSegment is a valid label. */
	{
		if (checkLabelValidityExists(lineSegment, labelCommand, 1)) /* Check if the label has already been defined in the code. */
		{
			/* If the label has already been defined, print an error message and set the "hasErrors" flag*/
			printf("Error Line:%d  label already defined as non external\n" , lineNumber);
			hasErrors = 1;
		}
		else /* If the label is new, add it to the command  as an external label*/
			addToCommand(&labelCommand, lineSegment, 0, "external", 0);
	}
	else
	{
		/* If the lineSegment is not a valid label, print an error message and set the "hasErrors" flag*/
		printf("Error Line:%d  label not leagal\n" , lineNumber);
		hasErrors = 1;
	}
}

/* This function processes a line of input that starts with the ".entry" directive*/
/* It expects a string of characters that separate words, a label name (if there is one), and the current line number*/
void entryHandler(char *seperators, char *labelName, int lineNumber)
{
	/* Get the next lineSegment (the label name), and check if it is a valid label*/
    char * lineSegment = strtok(NULL, seperators);
	if (checkLabelValidity(lineSegment, 0))
		addToCommand(&entCommand, lineSegment, 0, "entry", 0);  /* If it is a valid label, add it to the entry command linked command with the value 0 (since the address is not known yet)*/
}

/* This function handles a line of code by calling the appropriate functions to translate and store the command*/
/* The function takes a boolean flag indicating whether the line has a label, the command lineSegment, a string of separators, the label name (if any), and the line number*/
void commandHandler(int hasLabel, char * lineSegment, char *seperators, char *labelName, int lineNumber)
{
	/* If the line has a label, add the label command to the command linked command with the current instruction counter (IC) value*/
    /* Then, call the function to translate the command*/
    if (hasLabel)
	{
		addToCommand(&labelCommand, labelName, 0, "code", IC); 
		findCommand(lineSegment, seperators, labelName, lineNumber);
	}
	else /* If the line does not have a label, simply call the function to translate the command*/
		findCommand(lineSegment, seperators, NULL, lineNumber);
}

/* This function updates the address of each command in a linked command of commands by adding an offset to the current address*/
/* If the labelCommand parameter is 1, it only updates the address of commands with a type of "data"*/
void updateCommandAddress(command **head, int offset, int labelCommand)
{
	command* pntCommand;
	/* Loop through the linked command of commands */
	for (pntCommand = (*head); pntCommand; pntCommand = pntCommand->next)
	{
		/* If the labelCommand parameter is 1, only update the address of commands with a type of "data" */
	    if (labelCommand)
	    {
	        if(!strcmp(pntCommand->type, "data"))			
				pntCommand->address = pntCommand->address + offset; /* Add the offset to the current address of the command */
	    }
	    else  /* If the labelCommand parameter is not 1, update the address of all commands*/
		    pntCommand->address = pntCommand->address + offset; /* Add the offset to the current address of the command*/
	}
}
