/*מוחמד כנעאן - 205722176 */
/*שימאא עואד - 212083653 */
#include <stdio.h>
#include <string.h>

#define FILENAME_LENGTH 30

int error;

void removeMacros(char* fileAS, char* fileAM);
void firstStage(char* fileAM);
void secondStage(char* fileNameNoSuffix);

int main(int numArgs, char* argv[]) 
{
    char fileAM[FILENAME_LENGTH], fileAS[FILENAME_LENGTH], fileNameNoSuffix[FILENAME_LENGTH];  
	int i;

    if (numArgs <= 1) {
        printf("Please Enter a file name, .as and .am files\n");
    }
    else {
        for (i = 1; i < numArgs; i++) {
            strcpy(fileNameNoSuffix, argv[i]);
            strcpy(fileAS, fileNameNoSuffix);
            strcpy(fileAM, fileNameNoSuffix);
            strcat(fileAS, ".as");
            strcat(fileAM, ".am");
            removeMacros(fileAS, fileAM);

            firstStage(fileAM);
            if (!error) {
                secondStage(fileNameNoSuffix);
                printf("%s file translated successfully\n", fileAS);
            }
        }
    }
    return 1;
}

