/*מוחמד כנעאן - 205722176 */
/*שימאא עואד - 212083653 */
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

/* Functiuon  */
/* Finds the opcode for a given command and stores it in an integer variable*/
void findOpcode(char *cmd, int *output, int lineNumber);

/* Finds the register number for a given register name and stores it in an integer variable*/
void findRegister(char *val, char mode[], int *output, int lineNumber);

/* Finds the addressing method for a given operand and stores it in an integer variable*/
void findteMethod(char *val, char * mode, int *output, int lineNumber);

/* Finds the immediate value for a given operand and stores it in an integer variable*/
void findImmidiate(char *val, int *output);

/* Finds the command for a given lineSegment and stores it in a string variable*/
void findCommand(char *currentlineSegment, char *seporators, char *labelName, int lineNumber);

/* Determines if a command takes no operands*/
int commandWithoutOperands(char * commandName);

/* Determines if a command takes two operands*/
int commandWithTwoOperands(char * commandName);

/* Processes a command with no operands and updates the code accordingly*/
void findNoOperandsCommand(char * commandName,char *lineSegment, int lineNumber);

/* Processes a command with one operand and updates the code accordingly*/
void findOneOperandCommand(char * commandName, char *lineSegment, char *labelName,char * arg1, int lineNumber);

/* Processes a command with two operands and updates the code accordingly*/
void findTowOperandsCommand(char * commandName,char *lineSegment, char *labelName,char * arg1, char * arg2, int lineNumber);

/* Processes a command with three operands and updates the code accordingly*/
void findThreeOperandCommand(char *commandName, char *lineSegment, char *labelName, char *arg1, char *arg2, char *arg3, int lineNumber);
