/*מוחמד כנעאן - 205722176 */
/*שימאא עואד - 212083653 */
#include "dataTypes.h"
#include "find.h"
#include "functions.h"

int DC, IC;
command *codeCommand;
int hasErrors;

/* This defines a struct Command with two fields: name (a string) and opcode (an integer). */
typedef struct {
    char *name;
    int opcode;
} asmCommand;

/* This defines an array commands of Command structs, with each struct containing a command name and its corresponding opcode value. */
asmCommand commands[] = {
    {"cmp", 1},
    {"add", 2},
    {"sub", 3},
    {"not", 4},
    {"clr", 5},
    {"lea", 6},
    {"inc", 7},
    {"dec", 8},
    {"jmp", 9},
    {"bne", 10},
    {"red", 11},
    {"prn", 12},
    {"jsr", 13},
    {"rts", 14},
    {"stop", 15}
};

/*This calculates the number of commands in the commands array. */
int NUM_COMMANDS = sizeof(commands) / sizeof(asmCommand);

/* If a matching command is found, the function sets the opcode value in the output integer using bitwise OR and left shift operations. */
/* If no matching command is found, the function prints an error message and sets a global flag hasErrors to indicate that errors were found during assembly. */
void findOpcode(char *cmd, int *output, int lineNumber)
{
    int i;
    for (i = 0; i < NUM_COMMANDS; i++) {
        if (!strcmp(cmd, commands[i].name)) /* check if cmd matches the current command name */
		{
            *output |= (commands[i].opcode << 6); /* shift the opcode left by 6 bits and bitwise OR with output */
            return;
        }
    }
    /* print an error message indicating that the command was not found */
    printf("Error Line:%d  command not found\n" , lineNumber);
    hasErrors = 1;
}

/* Strip the '#' character from the lineSegment and interpret the remaining string as a decimal value. 
 Then, convert the decimal value to a 10-bit 2's complement number and merge it with the output.*/
void findImmidiate(char *tok, int *output)
{
	/* Strip the '#' character from the lineSegment and interpret the remaining string as a decimal value*/
	char * num = malloc(strlen(tok)-1);
	int number;
	strcpy(num, tok+1);
	number = atoi(num); /* Convert the string number to an integer*/
	*output = (*output | (-((~number) +1 ) & 1023)<<2); /* Convert the integer to 10-bit 2's complement and merge with the output*/
}

/* Extract the register number from the lineSegment and interpret it as a decimal value */
void findRegister(char *tok, char *mode, int *output, int lineNumber)
{
	/* Strip the 'r' character from the lineSegment and interpret the remaining string as a decimal value */
	char * num = malloc(strlen(tok)-1);
	int number;
	strcpy(num, tok+1);
	number = atoi(num);
	/* Check if the register number is in the valid range of 0 to 7 */
	if(number >= 0 && number <= 7)
	{
		/* Determine whether the register is for the source or destination operand */
	    if (!strcmp(mode, "source"))
		    *output = (*output | (number<<8)); /* Set the source register field (bits 8-10) to the given register number */
	    else if (!strcmp(mode, "destination"))
		    *output = (*output | (number<<2)); /* Set the destination register field (bits 2-5) to the given register number */
	}
	else
	{
	    /* If the register number is out of range, print an error message and set the hasErrors flag*/
		printf("Error Line:%d  illigal reg number\n" , lineNumber);
		hasErrors = 1;
	}
}

/* Find the addressing method represented by 'tok' into the appropriate bits of the output word.
 'mode' indicates whether the addressing mode is for the source or destination operand.*/
void findMethod(char *tok, char * mode, int *output, int lineNumber)
{
    /* Direct addressing*/
    if (getMethodNumber(tok)==1)
	{
		if (!strcmp(mode, "source"))
			*output = (*output | 1<<4); /* Set bits 4-5 to 01 to indicate direct addressing for the source operand*/
		else if (!strcmp(mode, "destination"))
			*output = (*output | 1<<2); /* Set bits 2-3 to 01 to indicate direct addressing for the destination operand*/
	}

    /* Struct addressing*/
	else if(getMethodNumber(tok)==2)
	{
		if (!strcmp(mode, "source"))
			*output = (*output | 2<<4); /* Set bits 4-5 to 10 to indicate struct addressing for the source operan*/
		else if (!strcmp(mode, "destination"))
			*output = (*output | 2<<2); /* Set bits 2-3 to 10 to indicate struct addressing for the destination operand*/
	}

	/* Register addressing*/
	else if (getMethodNumber(tok)==3)
	{
		if (!strcmp(mode, "source"))
			*output = (*output | 3<<4); /* Set bits 4-5 to 11 to indicate register addressing for the source operand*/
		else if (!strcmp(mode, "destination"))
			*output = (*output | 3<<2); /* Set bits 2-3 to 11 to indicate register addressing for the destination operand*/
	}
	else if (getMethodNumber(tok))
	{
			printf("Error Line:%d  illigal methon %s\n" , lineNumber, tok); /* Error: the method number is not 0, 1, 2, or 3, so it is an illegal method*/
			hasErrors = 1;
	}

}

/* This function finds the command in the instruction and its operands, then passes them for translation */
void findCommand(char *lineSegment, char *seperators, char *labelName, int lineNumber)
{
	char *arg1 = NULL, *arg2 = NULL, *arg3 = NULL;
	char *commandName = lineSegment; /* Extract the command name from the instruction */
	int i;
	/* Extract the arguments from the instruction */
	for (i = 0; i < 3; i++) {
    	lineSegment = strtok(NULL, seperators);
    	if (lineSegment != NULL)
		{
        	if (i == 0) arg1 = lineSegment;
			else if (i == 1) arg2 = lineSegment;
			else if (i == 2) arg3 = lineSegment;
	    }
	}

	/* Check for too many operands */
	lineSegment = strtok(NULL, seperators);
	if (lineSegment != NULL)
	{
		/* Error message when too many operands are provided */
		printf("Error Line:%d  too many operands\n" , lineNumber);
		hasErrors = 1;
	}

	/* Determine the number of operands and call the appropriate function for translation */
	if (lineSegment != NULL){
			/* error: too many operands */
			printf("Line:%d  too many operands\n" , lineNumber);
			hasErrors = 1;
		}
		/*if three operands*/
		else if (arg3 != NULL)
		    findThreeOperandCommand(commandName,lineSegment,labelName, arg1, arg2, arg3, lineNumber);
		/*if two operands*/
		else if (arg2 != NULL)
		    findTowOperandsCommand(commandName,lineSegment,labelName, arg1, arg2, lineNumber);
		/*if has  one operand*/
		else if (arg1 != NULL)
		    findOneOperandCommand(commandName,lineSegment,labelName, arg1, lineNumber);
		/*if has no operands */
		else
        	findNoOperandsCommand(commandName,lineSegment, lineNumber);
}

/* This function checks whether a command needs zero operands by comparing its name to "rts" and "stop". */
int commandWithTwoOperands(char * commandName)
{
   if(!strcmp(commandName, "rts") || !strcmp(commandName, "stop"))
        return 1;
   return 0;
}

/* This function checks whether a given command requires two operands or not. */
int needsTwoOperands(char* commandName) {
   if(!strcmp(commandName, "mov") ||
      !strcmp(commandName, "add") ||
      !strcmp(commandName, "sub") ||
      !strcmp(commandName, "lea") ||
      !strcmp(commandName, "cmp"))
        return 1;
   return 0;
}

/* This function finds a command that requires no operands into machine code. */
void findNoOperandsCommand(char * commandName,char *lineSegment, int lineNumber)
{
    int output1 = 0;
    char *type = "a";

	/* Find opcode for commandName*/
	findOpcode(commandName, &output1, lineNumber);
    
	/* If the command is not RTS or HLT, it requires operands */
	if (commandWithTwoOperands(commandName) == 0)
	{
		printf("Error Line:%d  too few operands for %s\n" , lineNumber, commandName);
		hasErrors = 1;	
	}
	else
	{
		/* Add instruction to code command */
		addToCommand(&codeCommand, "", output1, type, IC);
	    ++IC;
	}
}


void findOneOperandCommand(char * commandName, char *lineSegment, char *labelName,char * arg1, int lineNumber)
{
	char *type = "a";
	int output1, output2;
	output1 = output2 = 0;

	findOpcode(commandName, &output1, lineNumber);

	/* Check for incorrect number of operands */
    if(commandWithTwoOperands(commandName))
	{
        /* Error: Too many operands, command should not have operands*/
		printf("Error Line:%d  too many operands\n" , lineNumber);
		hasErrors = 1;
	}
				
	else if(needsTwoOperands(commandName))
	{
		/* Error: Too few operands, command should have two operands*/
		printf("Error Line:%d  too few operands\n" , lineNumber);
		hasErrors = 1;
	}
	else if (strcmp(commandName, "prn") != 0 && !getMethodNumber(arg1))
 	/* Check for incorrect method*/
	{
		/* Error: Incorrect method, only prn can be with method 0*/
		printf("Error Line:%d  incorrect operand %s for %s\n" , lineNumber, arg1, commandName);
		hasErrors = 1;
	}
	else
	{
		/* Find the addressing method for the operand*/
	    findMethod(arg1, "destination", &output1, lineNumber);

		/* Add the first word to the code Command*/
		addToCommand(&codeCommand, "", output1, type, IC);
		++IC;

		/* Handle the operand depending on its addressing method    */
	    if (getMethodNumber(arg1)==3)
		{
			/* Register addressing method*/
			findRegister(arg1, "destination", &output2, lineNumber);
		    addToCommand(&codeCommand, "", output2, type, IC);
	        ++IC;
		}
		else if (getMethodNumber(arg1)==0)
		{
			/* Immediate addressing method*/
		    findImmidiate(arg1, &output2);
			addToCommand(&codeCommand, "", output2, type, IC);
	        ++IC;
		}
		else if (getMethodNumber(arg1)==1)
		{
			/* Direct addressing method*/
		    labelName = malloc(sizeof(arg1));
	        strcpy(labelName ,arg1);
	        addToCommand(&codeCommand, labelName, output2, type, IC);
	       ++IC;
		}
	}
}

void findTowOperandsCommand(char *commandName, char *lineSegment, char *labelName, char *arg1, char *arg2, int lineNumber)
{
    char *type = "a";
    int output1, output2, output3;
    output1 = output2 = output3 = 0;

    findOpcode(commandName, &output1, lineNumber);

    /* Check number of operands*/
    if (!needsTwoOperands(commandName))
	{
        /* Error: command needs zero or one operands */
        printf("Error Line:%d  too many operands\n", lineNumber);
        hasErrors = 1;
    } else {
        /* Check if the operands are legal for the command */
       if ((!strcmp(commandName, "lea")) && (!getMethodNumber(arg1) || getMethodNumber(arg1) == 3))
		{
            /* Error: lea command is not legal with src method 0 and 3 */
            printf("Error Line:%d  incorrect operand: %s is not legal with %s\n", lineNumber, commandName, arg1);
            hasErrors = 1;
        } 
		else if (strcmp(commandName, "cmp") != 0 && !getMethodNumber(arg2))
		{
            /* Dest method 0 is legal only in cmp command */
            printf("Error Line:%d  incorrect operand: %s is not legal with %s\n", lineNumber, commandName, arg2);
            hasErrors = 1;
        } else {
            /* Find method for source operand*/
            findMethod(arg1, "source", &output1, lineNumber);
            /* Find method for destination operand*/
            findMethod(arg2, "destination", &output1, lineNumber);
            addToCommand(&codeCommand, "", output1, type, IC);
            ++IC;

        switch (getMethodNumber(arg1)) 
		{
			case 0:
				findImmidiate(arg1, &output2);
				addToCommand(&codeCommand, "", output2, type, IC);
				++IC;
				break;
			case 1:
				labelName = malloc(sizeof(arg1));
				strcpy(labelName, arg1);
				addToCommand(&codeCommand, labelName, output2, type, IC);
				++IC;
				break;
			case 3:
				findRegister(arg1, "source", &output2, lineNumber);
				if (getMethodNumber(arg2) == 3) {
					findRegister(arg2, "destination", &output2, lineNumber);
				}
				addToCommand(&codeCommand, "", output2, type, IC);
				++IC;
				break;
			default:
				/* Handle invalid method number*/
					break;
			}

			/* Add extra words for arg2*/
			switch (getMethodNumber(arg2)) 
			{
				case 3:
					if (getMethodNumber(arg1) != 3) {
						findRegister(arg2, "destination", &output3, lineNumber);
						addToCommand(&codeCommand, "", output3, type, IC);
						++IC;
					}
					break;
				case 0:
					findImmidiate(arg2, &output3);
					addToCommand(&codeCommand, "", output3, type, IC);
					++IC;
					break;
				case 1:
					labelName = malloc(strlen(arg2) + 1);
					strcpy(labelName, arg2);
					addToCommand(&codeCommand, labelName, output3, type, IC);
					++IC;
					break;
				default:
					/* handle invalid argument error*/
					break;
			}
        }
    }
}


void findThreeOperandCommand(char *commandName, char *lineSegment, char *labelName, char *arg1, char *arg2, char *arg3, int lineNumber)
{
    char *type = "a";
    int output1, output2, output3, output4;
    output1 = output2 = output3 = output4 = 0;

    /* first word - opcode */
    findOpcode(commandName, &output1, lineNumber);

    /* check for too many operands */
    if (needsTwoOperands(commandName) == 1 || commandWithTwoOperands(commandName) == 1)
    {
        /* error: too many operands, needs to be zero operands */
        printf("Error Line:%d  too many operands\n", lineNumber);
        hasErrors = 1;
    }
    else
    {
        /* set bits for first word */
        output1 |= 2 << 2;
        output1 |= getMethodNumber(arg3) << 10;
        output1 |= getMethodNumber(arg2) << 12;

        /* add first word to code Command */
        addToCommand(&codeCommand, "", output1, type, IC);
        ++IC;

        /* add label for first argument */
        labelName = malloc(sizeof(arg1));
        strcpy(labelName, arg1);
        addToCommand(&codeCommand, labelName, output2, type, IC);
        ++IC;

        /* add extra words for arg2 */
		switch (getMethodNumber(arg2)) {
			case 3: /* handle register*/
				findRegister(arg2, "source", &output3, lineNumber);
				
				/* handle destination register*/
				if (getMethodNumber(arg3) == 3) {
					findRegister(arg3, "destination", &output3, lineNumber);
				}
				
				/* add second word to code Command*/
				addToCommand(&codeCommand, "", output3, type, IC);
				++IC;
				break;
				
			case 0: /* handle immediate value*/
				findImmidiate(arg2, &output3);
				
				/* add second word to code Command*/
				addToCommand(&codeCommand, "", output3, type, IC);
				++IC;
				break;
				
			case 1: /* handle label*/
				labelName = malloc(sizeof(arg2));
				strcpy(labelName, arg2);
				
				/* add second word to code Command */
				addToCommand(&codeCommand, labelName, output3, type, IC);
				++IC;
				break;
				
			default:
				/* handle invalid case*/
				break;
		}


        /* add extra words for arg3 */
        if (getMethodNumber(arg3) == 3)
        {
            if (getMethodNumber(arg2) != 3)
            {
                /* handle destination register */
                findRegister(arg3, "destination", &output4, lineNumber);

                /* add third word to code Command */
                addToCommand(&codeCommand, "", output4, type, IC);
                ++IC;
            }
        }
        else if (getMethodNumber(arg3) == 0)
        {
            /* handle immediate value */
            findImmidiate(arg3, &output4);

            /* add third word to code Command */
            addToCommand(&codeCommand, "", output4, type, IC);
            ++IC;
        }
        else if (getMethodNumber(arg3) == 1)
        {
            /* handle label */
            labelName = malloc(sizeof(arg3));
            strcpy(labelName, arg3);

            /* add third word to code Command */
            addToCommand(&codeCommand, labelName, output4, type, IC);
            ++IC;
        }
	}
}
