/*מוחמד כנעאן - 205722176 */
/*שימאא עואד - 212083653 */
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

/* This function is responsible for the second pass of the assembler. It reads the input file, processes the instructions and writes the output to the appropriate files*/
void secondStage(char *fileName);

/* This function updates the address of each label in the command command*/
void updateLabelAdd(command **headCode,command *headlabel);

/* This function updates the addresses of external variables in the command command*/
void updateExt(command **head, command *headext);

/* This function writes the machine code of the assembled program to the object file*/
void printToObFile(char *fileName);

/* This function writes the machine code of a command to a specified output file*/
void printToFile(command *head, FILE *outputFile);

/* This function writes the command of external variables to a specified output file*/
void printToExt(char *fileName, command* head, char *type);

/* This function writes the command of entry variables to a specified output file*/
void printToEnt(char *fileName , command* head, command* headEnt);
 
