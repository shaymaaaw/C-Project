/*מוחמד כנעאן - 205722176 */
/*שימאא עואד - 212083653 */
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

/* This function checks if a given value is a valid label. The second argument withColon is a flag that indicates whether the label should end with a colon or not. */
int checkLabelValidity(char val[], int withColon); 

/* This function checks if a given label exists in a linked list of commands. The third argument external is a flag that indicates whether the label can be defined in an external file.*/
int checkLabelValidityExists(char *label, command *headlabel, int external); 

/* This function checks if a given value is a valid register.*/
int checkRegisterValidity(char *val);

/* This function checks if a given value is a valid immediate value.*/
int checkImmidiateValidity(char *val); 

/* This function checks if a given value is a valid number.*/
int checkNumberValidity(char *val); 

/* This function adds a new command to a linked list of commands. The arguments label, number, val, and address correspond to the different fields of the command structure.*/
void addToCommand(command **head, char *label, int number, char *val, int address); 

/* This function clears a linked list of commands.*/
void clearCommand(command **headCode);

/* This function returns the method number of a given command.*/
int getMethodNumber(char *val); 

/* This function removes all macro definitions from a given input file and saves the result to a new output file.*/
void removeMacros(char *file, char *amFile);

/* This function checks if a given value is a valid jump parameter.*/
int checkJumpValidity(char *val); 

 /* This function extracts the label from a jump command.*/
char * extractJumpLabel(char *tok);

/* This function extracts the first parameter from a jump command.*/
char * extractJumpFirstParam(char *val); 
