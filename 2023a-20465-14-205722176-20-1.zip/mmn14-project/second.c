/*מוחמד כנעאן - 205722176 */
/*שימאא עואד - 212083653 */
#include "dataTypes.h"
#include "main.h"

command* codeCommand, *dataCommand, *labelCommand, *extCommand, *entCommand;


/* Second stage of the assembly process: */
void secondStage(char *fileName)
{
    /* Update label addresses in the code command */
	updateLabelAdd(&codeCommand, labelCommand);
	
	/* Update external addresses in the code Command */
	updateExt(&codeCommand, extCommand);
	
	/*  Print machine code of code to .ob file*/
	strcat(fileName, ".ob");
	printToObFile(fileName);
	
	/* Print external labels to .ext file */
	fileName[strlen(fileName)-2] = 0;     
	strcat(fileName, "ext");
	printToExt(fileName, codeCommand, "e");
	
	/* Print entry labels to .ent file*/
	fileName[strlen(fileName)-3]=0;     
	strcat(fileName, "ent");
	printToEnt(fileName, labelCommand, entCommand);

    /* Free up memory allocated for command structures*/
    clearCommand(&codeCommand);
	clearCommand(&dataCommand);
	clearCommand(&labelCommand);
	clearCommand(&extCommand);
	clearCommand(&entCommand);
}

/* This function updates the label addresses in the code commands by iterating over the Command*/
/* of code commands and comparing the command name to the label names in the label commands Command.*/
void updateLabelAdd(command **head, command *headLabel)
{
    command* pntCommand1 = *head, *pntCommand2;
    char temp[30];
	
    /* Loop over code commands*/
    for (pntCommand1 = *head; pntCommand1; pntCommand1 = pntCommand1->next)
    {
        /* Check if current command is a label*/
        if (checkLabelValidity(pntCommand1->name, 0)) 
        {
            /* Loop over label commands*/
            for (pntCommand2 = headLabel; pntCommand2; pntCommand2 = pntCommand2->next) 
            {
                /* Get label name without colon*/
                strcpy(temp, pntCommand2->name);
                temp[strlen(temp) - 1] = 0; 

                /* Compare command name to label name (with or without colon)*/
                if (!strcmp(pntCommand1->name, temp) || !strcmp(pntCommand1->name, pntCommand2->name))
                {
                    /* Update command address with label address*/
                    if (strcmp(pntCommand2->type, "external") != 0)
                    {
                        pntCommand1->num = pntCommand2->address << 2;
                        /* Mark the R bit*/
                        pntCommand1->num = pntCommand1->num | 2;
                    }
                    /* If label is external*/
                    else
                    {
                        /* Mark the E bit*/
                        pntCommand1->num = pntCommand1->num | 1;
                        /* Add to external commands Command*/
                        addToCommand(&extCommand, pntCommand1->name, 0, "e", pntCommand1->address);
                    }
                }
            }
        }
    }
}

/* Update external symbol address in Commandcode*/
void updateExt(command **head, command *headex)
{
	command* pntCommand1, *pntCommand2; /* Pointer to copy of Commandext and address of Commandcode*/

	for (pntCommand1 = (*head); pntCommand1 != NULL; pntCommand1 = pntCommand1->next)
	{
		/* Check if the current command is a label and if it exists in the external symbol table*/
		if (checkLabelValidity(pntCommand1->name, 0))
		{
			for(pntCommand2 = headex;pntCommand2 != NULL;pntCommand2 = pntCommand2->next)
				if (!strcmp(pntCommand2->name, pntCommand1->name))
				{
					/* If the label is external, mark it as such*/
					strcpy(pntCommand1->type ,"e");
					break;		
				}
		}
	}
}

/* Print the machine code of the code commands and the data commands to an output file with the given file name.*/
void printToObFile(char *fileName)
{
    FILE *outputFile;
    outputFile = fopen(fileName, "w");
	fprintf(outputFile, "Base 10 address  Base 2 code\n");
	fprintf(outputFile, "           23    11\n");
	printToFile(codeCommand , outputFile);
	fclose(outputFile);
	
	/* Append the machine code of the data at the end of the file */
	outputFile = fopen(fileName, "a+");
	printToFile(dataCommand , outputFile);
	fclose(outputFile);
}

/* Print the value of each command in the linked Command to the output file.*/
/* Each command's value is printed in binary, with a leading counter and zeros.*/
/* A modified binary string is also printed, where 1's are represented by slashes and 0's are represented by dots.*/
void printToFile(command *head, FILE *outputFile)
{
	int num; 
	char binary[15];
	char modified[15];
	while (head != NULL)
	{
        int i = 14, j;
	    num = head->num & 16383;
		
		fprintf(outputFile, "       %04d ", head->address);
			
        memset(binary, '0', sizeof(binary));
        binary[14] = '\0';
        modified[14] = '\0';

        while (num > 0) {
            binary[--i] = num % 2 + '0';
            num /= 2;
        }
		/* Replace 1's with slashes and 0's with dots in the modified binary string*/
        for (j = 0; j < strlen(binary); j++)
        {
            if (binary[j] == '0')
                modified[j] = '.';
            else if (binary[j] == '1')
                modified[j] = '/';
        }

		fprintf(outputFile, "        %s",modified);
		head = head->next;
		
		fprintf(outputFile,"\n");
	}
}


/* This function prints the symbols table to a file. It takes the name of the output file,*/
/* The head of the symbols table, and the type of the symbols to print as arguments.*/
void printToExt(char *fileName, command* head, char *type)
{
    int i;
	command*  pntCommand;
    FILE *outputFile;
	outputFile = fopen(fileName, "w");

	for (pntCommand = (head); pntCommand; pntCommand = pntCommand->next)
	{
		if (!strcmp(pntCommand->type,type)) /* Check if the command is of the specified type*/
		{
			    fprintf(outputFile, "%s", pntCommand->name); /* rint the command name with padding spaces to align columns*/
			    for(i=10-strlen(pntCommand->name); i>0; i--)
			        fprintf(outputFile, " ");
			    fprintf(outputFile, "%d\t\n", pntCommand->address); /* Print the command address with a newline character */
		}
	}
	fclose(outputFile);
}

/* Print the Commandent in a file.*/
/* This function takes in a filename, a linked Command of Commandcode and a linked Command of Commandent.*/
void printToEnt(char *fileName , command* head, command* headEnt)
{
    int i;
	command* pntCommand1, *pntCommand2;
	
	char temp[30];
    FILE *outputFile;
    outputFile = fopen(fileName, "w");
	/*pntCommand1  is pointing to the address of Commandcode*/
	for (pntCommand1 = (head); pntCommand1 != NULL; pntCommand1 = pntCommand1->next) 
	{
	    /*pntCommand2  is pointing to copy of Commandent*/
		pntCommand2 = headEnt; 
			strcpy(temp ,pntCommand1->name);
			temp[strlen(temp)-1]=0; 
			while (pntCommand2 != NULL )
			{
				if (strcmp(pntCommand2->name, temp ) == 0)
				{
					pntCommand2->address = pntCommand1->address;
					fprintf(outputFile,"%s",  pntCommand2->name);
					for(i=10-strlen(pntCommand2->name); i>0; i--)
			            fprintf(outputFile, " ");
					fprintf(outputFile,"%d\t\n",  pntCommand1->address);  
				}
				pntCommand2 = pntCommand2->next;
			}
	}
	fclose(outputFile);
}
